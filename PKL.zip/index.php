<?php 
    $nama = $_GET['name'];
    
    echo $nama;




?>